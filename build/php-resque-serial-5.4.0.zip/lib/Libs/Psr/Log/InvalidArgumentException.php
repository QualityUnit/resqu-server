<?php

namespace Resque\Libs\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
