<?php

namespace Resque\Protocol;

class Exceptions {

    const CODE_RESCHEDULE = -1;
    const CODE_RETRY = -2;

}