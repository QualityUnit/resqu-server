<?php


namespace Resque;

/**
 * All exceptions thrown from resque api will be descendants of this class.
 */
abstract class ResqueException extends \Exception {

}