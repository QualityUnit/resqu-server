<?php


namespace Resque\Scheduler;


interface IScheduler {

    function execute();

}