<?php


namespace Resque\Protocol;


use Resque\ResqueException;

class DeferredException extends ResqueException {

}