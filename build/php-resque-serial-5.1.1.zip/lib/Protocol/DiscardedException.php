<?php

namespace Resque\Protocol;

use Resque\ResqueException;

class DiscardedException extends ResqueException {

}